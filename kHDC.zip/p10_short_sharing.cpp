#include <iostream>
#include <graphics.h>
using namespace std;

void drawObject(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, int color) {
    setcolor(color);
    line(x1, y1, x2, y2);
    line(x2, y2, x3, y3);
    line(x3, y3, x4, y4);
    line(x4, y4, x1, y1);
}

void applyShear(int &x, int &y, float shX, float shY) {
    x += shX * y;
    y += shY * x;
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int x1 = 100, y1 = 100, x2 = 200, y2 = 100, x3 = 200, y3 = 200, x4 = 100, y4 = 200;
    drawObject(x1, y1, x2, y2, x3, y3, x4, y4, WHITE);

    cout << "1. X Shear  2. Y Shear  3. Both X and Y Shear\n";
    int option; cin >> option;
    float shX = 0, shY = 0;

    if (option == 1) cin >> shX;
    else if (option == 2) cin >> shY;
    else if (option == 3) cin >> shX >> shY;

    applyShear(x1, y1, shX, shY); applyShear(x2, y2, shX, shY);
    applyShear(x3, y3, shX, shY); applyShear(x4, y4, shX, shY);

    cleardevice();
    drawObject(x1, y1, x2, y2, x3, y3, x4, y4, RED);

    getch();
    closegraph();
    return 0;
}

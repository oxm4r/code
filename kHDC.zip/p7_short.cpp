#include <graphics.h>
#include <iostream>

using namespace std;

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int choice, tx, ty;
    cout << "Choose the shape: \n1. Rectangle\n2. Circle\n3. Triangle\n";
    cin >> choice;
    cout << "Enter translation factors (tx, ty): ";
    cin >> tx >> ty;

    switch (choice) {
        case 1: 
            rectangle(100, 100, 200, 150);
            rectangle(100 + tx, 100 + ty, 200 + tx, 150 + ty);
            break;
        case 2: 
            circle(200, 200, 50);
            circle(200 + tx, 200 + ty, 50);
            break;
        case 3: 
            line(250, 250, 300, 350);
            line(300, 350, 200, 350);
            line(200, 350, 250, 250);
            line(250 + tx, 250 + ty, 300 + tx, 350 + ty);
            line(300 + tx, 350 + ty, 200 + tx, 350 + ty);
            line(200 + tx, 350 + ty, 250 + tx, 250 + ty);
            break;
        default:
            cout << "Invalid choice!";
    }

    getch();
    closegraph();
    return 0;
}

#include <graphics.h>
#include <stdio.h>

void scaleShape(int choice, int x, int y, int p1, int p2, int sx, int sy) {
    if (choice == 1) { 
        rectangle(x, y, x + p1, y + p2);
        rectangle(x, y, x + p1 * sx, y + p2 * sy);
    } else if (choice == 2) { 
        circle(x, y, p1);
        circle(x, y, p1 * sx);
    } else { 
        line(x, y, x + p1, y);
        line(x + p1, y, x, y + p2);
        line(x, y + p2, x, y);
        line(x, y, x + p1 * sx, y + p2 * sy);
        line(x + p1 * sx, y + p2 * sy, x, y + p2 * sy);
        line(x, y + p2 * sy, x, y);
    }
}

int main() {
    int gd = DETECT, gm, choice, sx, sy;
    initgraph(&gd, &gm, "");

    printf("Choose shape: 1.Rectangle 2.Circle 3.Triangle\n");
    scanf("%d", &choice);
    printf("Enter scaling factors (sx, sy): ");
    scanf("%d %d", &sx, &sy);

    if (choice == 1) scaleShape(1, 100, 100, 100, 50, sx, sy);  
    else if (choice == 2) scaleShape(2, 200, 200, 50, 0, sx, 0); 
    else scaleShape(3, 250, 250, 50, 50, sx, sy);               

    getch();
    closegraph();
    return 0;
}

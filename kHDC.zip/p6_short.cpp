#include <graphics.h>
#include <math.h>
#include <iostream>
using namespace std;

int offset = 100;
void rotateAndDraw(float x[], float y[], int n, float angle) {
    float rad = angle * (M_PI / 180.0);  
    for (int i = 0; i < n; i++) {       
        float x_new = x[i] * cos(rad) - y[i] * sin(rad);
        float y_new = x[i] * sin(rad) + y[i] * cos(rad);
        x[i] = x_new;
        y[i] = y_new;
    }
    for (int i = 0; i < n; i++)         
        line(x[i] + offset, y[i] + offset, x[(i + 1) % n] + offset, y[(i + 1) % n] + offset);
}

int main() {
    int gd = DETECT, gm, choice;
    float angle;
    initgraph(&gd, &gm, "");

    cout << "Select shape to rotate:\n1. Triangle\n2. Rectangle\n3. Circle\nEnter choice: ";
    cin >> choice;
    cout << "Enter rotation angle: ";
    cin >> angle;

    cleardevice();
    if (choice == 1) {  
        float x[] = {100, 150, 200}, y[] = {100, 50, 100};
        rotateAndDraw(x, y, 3, angle);
    } else if (choice == 2) {  
        float x[] = {100, 200, 200, 100}, y[] = {100, 100, 200, 200};
        setcolor(GREEN);
        rectangle(100+offset,200+offset,200+offset,100+offset);
        setcolor(RED);
        rotateAndDraw(x, y, 4, angle);
    } else if (choice == 3) {  
        int radius = 50;
        float x = 150, y = 150;
        setcolor(GREEN);

        circle(x + offset, y + offset, radius);
        x = x * cos(angle * M_PI / 180.0) - y * sin(angle * M_PI / 180.0);
        y = x * sin(angle * M_PI / 180.0) + y * cos(angle * M_PI / 180.0);
        setcolor(RED);

        circle(x + offset, y + offset, radius);
    } else {
        cout << "Invalid choice!";
    }

    getch();
    closegraph();
    return 0;
}

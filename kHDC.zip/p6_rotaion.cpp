#include <graphics.h>
#include <conio.h>
#include <math.h>
#include <iostream>

using namespace std;

const int OFFSET_X = 200;
const int OFFSET_Y = 200;


void rotatePoint(float& x, float& y, float angle) {
    float rad = angle * (M_PI / 180.0);  
    float x_new = x * cos(rad) - y * sin(rad);
    float y_new = x * sin(rad) + y * cos(rad);
    x = x_new;
    y = y_new;
}


void rotateTriangle(float angle) {
    
    float x1 = 100, y1 = 100;
    float x2 = 150, y2 = 50;
    float x3 = 200, y3 = 100;

    
    line(x1 + OFFSET_X, y1 + OFFSET_Y, x2 + OFFSET_X, y2 + OFFSET_Y);
    line(x2 + OFFSET_X, y2 + OFFSET_Y, x3 + OFFSET_X, y3 + OFFSET_Y);
    line(x3 + OFFSET_X, y3 + OFFSET_Y, x1 + OFFSET_X, y1 + OFFSET_Y);

    
    rotatePoint(x1, y1, angle);
    rotatePoint(x2, y2, angle);
    rotatePoint(x3, y3, angle);

    
    line(x1 + OFFSET_X, y1 + OFFSET_Y, x2 + OFFSET_X, y2 + OFFSET_Y);
    line(x2 + OFFSET_X, y2 + OFFSET_Y, x3 + OFFSET_X, y3 + OFFSET_Y);
    line(x3 + OFFSET_X, y3 + OFFSET_Y, x1 + OFFSET_X, y1 + OFFSET_Y);
}


void rotateRectangle(float angle) {
    
    float x1 = 100, y1 = 100;
    float x2 = 200, y2 = 100;
    float x3 = 200, y3 = 200;
    float x4 = 100, y4 = 200;

    
    rectangle(x1 + OFFSET_X, y1 + OFFSET_Y, x3 + OFFSET_X, y3 + OFFSET_Y);

    
    rotatePoint(x1, y1, angle);
    rotatePoint(x2, y2, angle);
    rotatePoint(x3, y3, angle);
    rotatePoint(x4, y4, angle);

    
    line(x1 + OFFSET_X, y1 + OFFSET_Y, x2 + OFFSET_X, y2 + OFFSET_Y);
    line(x2 + OFFSET_X, y2 + OFFSET_Y, x3 + OFFSET_X, y3 + OFFSET_Y);
    line(x3 + OFFSET_X, y3 + OFFSET_Y, x4 + OFFSET_X, y4 + OFFSET_Y);
    line(x4 + OFFSET_X, y4 + OFFSET_Y, x1 + OFFSET_X, y1 + OFFSET_Y);
}


void rotateCircle(float angle) {
    
    int radius = 50;
    float centerX = 150, centerY = 150;

    
    circle(centerX + OFFSET_X, centerY + OFFSET_Y, radius);

    
    rotatePoint(centerX, centerY, angle);

    
    circle(centerX + OFFSET_X, centerY + OFFSET_Y, radius);
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    
    int screenWidth = getmaxx(); 
    int screenHeight = getmaxy(); 

    
    line(0, screenHeight / 2, screenWidth, screenHeight / 2);

    
    line(screenWidth / 2, 0, screenWidth / 2, screenHeight);

    int choice;
    float angle;

    
    cout << "Select the object to rotate:" << endl;
    cout << "1. Triangle" << endl;
    cout << "2. Rectangle" << endl;
    cout << "3. Circle" << endl;
    cout << "Enter your choice: ";
    cin >> choice;

    cout << "Enter the angle of rotation: ";
    cin >> angle;

    
    cleardevice();

    
    line(0, screenHeight / 2, screenWidth, screenHeight / 2);
    line(screenWidth / 2, 0, screenWidth / 2, screenHeight);

    switch (choice) {
        case 1:
            rotateTriangle(angle);
            break;
        case 2:
            rotateRectangle(angle);
            break;
        case 3:
            rotateCircle(angle);
            break;
        default:
            cout << "Invalid choice!" << endl;
    }

    getch();
    closegraph();
    return 0;
}

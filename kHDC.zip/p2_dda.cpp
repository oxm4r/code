#include <graphics.h>
#include <iostream>
#include <math.h>  

using namespace std;

int main() {
    int gd = DETECT, gm;
    float x1, y1, x2, y2, dx, dy, steps, xIncrement, yIncrement, x, y;

    
    initgraph(&gd, &gm, "");

    cout << "Enter the starting point (x1, y1): ";
    cin >> x1 >> y1;
    cout << "Enter the ending point (x2, y2): ";
    cin >> x2 >> y2;

    
    dx = x2 - x1;
    dy = y2 - y1;

    
    steps = max(abs(dx), abs(dy));

    
    xIncrement = dx / steps;
    yIncrement = dy / steps;

    
    x = x1;
    y = y1;

    
    for (int i = 0; i <= steps; i++) {
        putpixel(round(x), round(y), RED);  
        x += xIncrement;  
        y += yIncrement;  
    }

    getch();  
    closegraph();  

    return 0;
}

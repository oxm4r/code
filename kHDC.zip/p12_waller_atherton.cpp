#include <graphics.h>
#include <unistd.h>
#include <stdio.h>



int min(int a, int b) {
    return (a < b) ? a : b;
}


int max(int a, int b) {
    return (a > b) ? a : b;
}
bool lineIntersection(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, int *ix, int *iy) {
    float a1 = y2 - y1, b1 = x1 - x2, c1 = a1 * x1 + b1 * y1;
    float a2 = y4 - y3, b2 = x3 - x4, c2 = a2 * x3 + b2 * y3;
    float determinant = a1 * b2 - a2 * b1;

    if (determinant == 0) return false;
    *ix = (b2 * c1 - b1 * c2) / determinant;
    *iy = (a1 * c2 - a2 * c1) / determinant;

    return (*ix >= min(x1, x2) && *ix <= max(x1, x2) && *iy >= min(y1, y2) && *iy <= max(y1, y2) &&
            *ix >= min(x3, x4) && *ix <= max(x3, x4) && *iy >= min(y3, y4) && *iy <= max(y3, y4));
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int rx1 = 80, ry1 = 80, rx2 = 400, ry2 = 300;
    rectangle(rx1, ry1, rx2, ry2);

    int poly[10] = {100, 100, 300, 50, 450, 200, 200, 400, 100, 100};
    drawpoly(5, poly);


    int clipped[20], k = 0, ix, iy;

    for (int i = 0; i < 8; i += 2) {
        int x1 = poly[i], y1 = poly[i+1], x2 = poly[(i+2)%10], y2 = poly[(i+3)%10];

        if (lineIntersection(x1, y1, x2, y2, rx1, ry1, rx2, ry1, &ix, &iy)) { clipped[k++] = ix, clipped[k++] = iy;  }
        if (lineIntersection(x1, y1, x2, y2, rx2, ry1, rx2, ry2, &ix, &iy)) { clipped[k++] = ix, clipped[k++] = iy;  }
        if (lineIntersection(x1, y1, x2, y2, rx2, ry2, rx1, ry2, &ix, &iy)) { clipped[k++] = ix, clipped[k++] = iy; }
        if (lineIntersection(x1, y1, x2, y2, rx1, ry2, rx1, ry1, &ix, &iy)) { clipped[k++] = ix, clipped[k++] = iy; }
    }

    for (int i = 0; i < 10; i += 2) {
        int px = poly[i], py = poly[i+1];
        if (px >= rx1 && px <= rx2 && py >= ry1 && py <= ry2) {
            clipped[k++] = px;
            clipped[k++] = py;
        }
    }

    if (k > 0 && clipped[0] != clipped[k-2] && clipped[1] != clipped[k-1]) {
        clipped[k++] = clipped[0];
        clipped[k++] = clipped[1];
    }

    printf("press any key to clip the polygon...");

    getchar();
    cleardevice();
    setcolor(GREEN);
    rectangle(rx1, ry1, rx2, ry2);

    if (k > 0) {
        setcolor(RED);
        drawpoly(k / 2, clipped);

    }

    getchar();
    closegraph();

    return 0;
}

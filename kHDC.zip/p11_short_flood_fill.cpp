#include <graphics.h>
using namespace std;

void floodFill(int x, int y, int oldColor, int newColor) {
    if (getpixel(x, y) == oldColor) {
        putpixel(x, y, newColor);
        floodFill(x + 1, y, oldColor, newColor);
        floodFill(x - 1, y, oldColor, newColor);
        floodFill(x, y + 1, oldColor, newColor);
        floodFill(x, y - 1, oldColor, newColor);
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    rectangle(50, 50, 150, 150);
    floodFill(70, 70, BLACK, YELLOW);

    getch();
    closegraph();
    return 0;
}

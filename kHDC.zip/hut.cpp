#include <graphics.h>
#include <conio.h>

void drawHut() {
    
    line(100, 300, 300, 300); 
    line(100, 300, 100, 200); 
    line(300, 300, 300, 200); 
    line(100, 200, 300, 200); 

    
    line(100, 200, 200, 100); 
    line(300, 200, 200, 100); 

    
    line(180, 300, 180, 250); 
    line(220, 300, 220, 250); 
    line(180, 250, 220, 250); 

    
    line(120, 220, 160, 220); 
    line(120, 260, 160, 260); 
    line(120, 220, 120, 260); 
    line(160, 220, 160, 260); 
    line(120, 240, 160, 240); 
    line(140, 220, 140, 260); 

    
    line(160, 300, 160, 310); 
    line(240, 300, 240, 310); 
    line(160, 310, 240, 310); 

    line(150, 310, 150, 320); 
    line(250, 310, 250, 320); 
    line(150, 320, 250, 320); 
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    drawHut();

    getch();
    closegraph();
    return 0;
}


























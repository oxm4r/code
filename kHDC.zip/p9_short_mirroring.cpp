#include <graphics.h>
#include <conio.h>
#include <stdio.h>


void drawTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {
    line(x1, y1, x2, y2);
    line(x2, y2, x3, y3);
    line(x3, y3, x1, y1);
}


void drawAxes(int axisX, int axisY) {
    setcolor(LIGHTGRAY);
    line(axisX, 0, axisX, getmaxy()); 
    line(0, axisY, getmaxx(), axisY); 
    setcolor(WHITE);
}


void mirrorPoint(int *x, int *y, int axisX, int axisY, int mirrorX, int mirrorY) {
    if (mirrorX) *y = 2 * axisY - *y; 
    if (mirrorY) *x = 2 * axisX - *x; 
}


void mirrorTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int axisX, int axisY, int mirrorX, int mirrorY) {
    mirrorPoint(&x1, &y1, axisX, axisY, mirrorX, mirrorY);
    mirrorPoint(&x2, &y2, axisX, axisY, mirrorX, mirrorY);
    mirrorPoint(&x3, &y3, axisX, axisY, mirrorX, mirrorY);
    drawTriangle(x1, y1, x2, y2, x3, y3);
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    
    
    
    int axisX = 300, axisY = 200;
    int x1 = 50+axisX, y1 = 150, x2 = 100+axisX, y2 = 50, x3 = 150+axisX, y3 = 150;

    int choice;

    while (1) {
        cleardevice();
        drawAxes(axisX, axisY); 
        drawTriangle(x1, y1, x2, y2, x3, y3); 

        printf("1. Mirror X-axis\n2. Mirror Y-axis\n3. Mirror both\n4. Exit\nChoice: ");
        scanf("%d", &choice);

        if (choice == 4) break; 

        
        mirrorTriangle(x1, y1, x2, y2, x3, y3, axisX, axisY, choice != 2, choice != 1);

        getch(); 
    }

    closegraph(); 
    return 0;
}


#include <graphics.h>
#include <iostream>
#include <math.h>

using namespace std;

int main() {
    int gd = DETECT, gm;
    float x1, y1, x2, y2, m, c, x, y;

    
    initgraph(&gd, &gm, "");

    cout << "Enter the starting point (x1, y1): ";
    cin >> x1 >> y1;
    cout << "Enter the ending point (x2, y2): ";
    cin >> x2 >> y2;

    
    m = (y2 - y1) / (x2 - x1);
    c = y1 - m * x1;

    
    for (x = x1; x <= x2; x++) {
        y = m * x + c;  
        putpixel(round(x), round(y), WHITE);  
    }

    getch();  
    closegraph();  

    return 0;
}

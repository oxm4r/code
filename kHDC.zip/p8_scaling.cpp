#include <graphics.h>
#include <iostream>

using namespace std;

void scaleRectangle(int x, int y, int sx, int sy) {
    
    rectangle(x, y, x + 100, y + 50);

    
    rectangle(x, y, x + 100 * sx, y + 50 * sy);
}

void scaleCircle(int x, int y, int r, int sr) {
    
    circle(x, y, r);

    
    circle(x, y, r * sr);
}

void scaleTriangle(int x1, int y1, int x2, int y2, int x3, int y3, int sx, int sy) {
    
    line(x1, y1, x2, y2);
    line(x2, y2, x3, y3);
    line(x3, y3, x1, y1);

    
    line(x1, y1, x1 + (x2 - x1) * sx, y1 + (y2 - y1) * sy);
    line(x1 + (x2 - x1) * sx, y1 + (y2 - y1) * sy, x1 + (x3 - x1) * sx, y1 + (y3 - y1) * sy);
    line(x1 + (x3 - x1) * sx, y1 + (y3 - y1) * sy, x1, y1);
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int choice, sx, sy;

    cout << "Choose the shape to scale: \n1. Rectangle\n2. Circle\n3. Triangle\n";
    cin >> choice;

    if (choice == 2) {
        int sr;
        cout << "Enter the scaling factor (sr) for the radius: ";
        cin >> sr;
        scaleCircle(200, 200, 50, sr);
    } else {
        cout << "Enter the scaling factors (sx, sy): ";
        cin >> sx >> sy;

        switch (choice) {
        case 1: 
            scaleRectangle(100, 100, sx, sy);
            break;
        case 3: 
            scaleTriangle(250, 250, 300, 350, 200, 350, sx, sy);
            break;
        default:
            cout << "Invalid choice!";
        }
    }

    getch();
    closegraph();
    return 0;
}

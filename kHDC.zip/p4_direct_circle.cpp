#include <graphics.h>
#include <iostream>
#include <cmath>

using namespace std;

int main() {
    int gd = DETECT, gm;
    int xc, yc, r;

    
    initgraph(&gd, &gm, "");

    cout << "Enter the center of the circle (xc, yc): ";
    cin >> xc >> yc;
    cout << "Enter the radius of the circle: ";
    cin >> r;

    
    for (int x = 0; x <= r; x++) {
        int y = sqrt(r * r - x * x);  

        
        putpixel(xc + x, yc + y, GREEN);  
        putpixel(xc - x, yc + y, GREEN);  
        putpixel(xc + x, yc - y, GREEN);  
        putpixel(xc - x, yc - y, GREEN);  
        putpixel(xc + y, yc + x, GREEN);  
        putpixel(xc - y, yc + x, GREEN);  
        putpixel(xc + y, yc - x, GREEN);  
        putpixel(xc - y, yc - x, GREEN);  
    }

    getch();  
    closegraph();  

    return 0;
}

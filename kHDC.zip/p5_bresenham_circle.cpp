#include <graphics.h>
#include <iostream>

using namespace std;


void bresenhamCircle(int xc, int yc, int r) {
    int x = 0, y = r;
    int d = 3 - 2 * r;  

    
    while (y >= x) {
        
        putpixel(xc + x, yc + y, GREEN);  
        putpixel(xc - x, yc + y, GREEN);  
        putpixel(xc + x, yc - y, GREEN);  
        putpixel(xc - x, yc - y, GREEN);  
        putpixel(xc + y, yc + x, GREEN);  
        putpixel(xc - y, yc + x, GREEN);  
        putpixel(xc + y, yc - x, GREEN);  
        putpixel(xc - y, yc - x, GREEN);  

        x++;

        
        if (d > 0) {
            y--;
            d = d + 4 * (x - y) + 10;
        } else {
            d = d + 4 * x + 6;
        }
    }
}

int main() {
    int gd = DETECT, gm;
    int xc, yc, r;

    
    initgraph(&gd, &gm, "");

    
    cout << "Enter the center of the circle (xc, yc): ";
    cin >> xc >> yc;
    cout << "Enter the radius of the circle: ";
    cin >> r;

    
    bresenhamCircle(xc, yc, r);

    getch();  
    closegraph();  

    return 0;
}

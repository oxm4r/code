#include <graphics.h>
#include <conio.h>
#include <stdio.h>
#include <math.h>


int axisX = 300, axisY = 200;


void drawAxes() {
    setcolor(LIGHTGRAY);
    line(axisX, 0, axisX, getmaxy()); 
    line(0, axisY, getmaxx(), axisY); 
    setcolor(WHITE);
}


void mirrorPoint(int x, int y, int mirrorX, int mirrorY, int *newX, int *newY) {
    *newX = mirrorY ? 2 * axisX - x : x; 
    *newY = mirrorX ? 2 * axisY - y : y; 
}


void scalePoint(int x, int y, float scaleX, float scaleY, int *newX, int *newY) {
    *newX = axisX + (int)((x - axisX) * scaleX); 
    *newY = axisY + (int)((y - axisY) * scaleY); 
}


void shearPoint(int x, int y, float shearX, float shearY, int *newX, int *newY) {
    int translatedX = x - axisX; 
    int translatedY = y - axisY;

    *newX = axisX + translatedX + (int)(shearX * translatedY); 
    *newY = axisY + translatedY + (int)(shearY * translatedX); 
}


void rotatePoint(int x, int y, float angle, int *newX, int *newY) {
    float radian = angle * M_PI / 180.0; 
    int translatedX = x - axisX; 
    int translatedY = y - axisY;

    *newX = axisX + (int)(translatedX * cos(radian) - translatedY * sin(radian)); 
    *newY = axisY + (int)(translatedX * sin(radian) + translatedY * cos(radian)); 
}


void drawTriangle(int x1, int y1, int x2, int y2, int x3, int y3) {
    line(x1, y1, x2, y2);
    line(x2, y2, x3, y3);
    line(x3, y3, x1, y1);
}


void displayMenu() {
    printf("\n--- Transformation Options ---\n");
    printf("1. Mirror X-axis\n");
    printf("2. Mirror Y-axis\n");
    printf("3. Mirror both axes\n");
    printf("4. Apply Scaling\n");
    printf("5. Apply Shearing\n");
    printf("6. Apply Rotation\n");
    printf("7. Reset to Original Triangle\n");
    printf("8. Exit\n");
    printf("Choose an option: ");
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    
    int originalX1 = 50 + axisX, originalY1 = 150;
    int originalX2 = 100 + axisX, originalY2 = 50;
    int originalX3 = 150 + axisX, originalY3 = 150;

    
    int x1 = originalX1, y1 = originalY1;
    int x2 = originalX2, y2 = originalY2;
    int x3 = originalX3, y3 = originalY3;

    int newX1, newY1, newX2, newY2, newX3, newY3;
    float scaleX, scaleY, shearX, shearY, angle;
    int choice;

    while (1) {
        cleardevice();
        drawAxes(); 
        drawTriangle(x1, y1, x2, y2, x3, y3); 

        displayMenu(); 
        scanf("%d", &choice);

        if (choice == 8) break; 

        switch (choice) {
            case 1: 
                mirrorPoint(x1, y1, 1, 0, &newX1, &newY1);
                mirrorPoint(x2, y2, 1, 0, &newX2, &newY2);
                mirrorPoint(x3, y3, 1, 0, &newX3, &newY3);
                break;
            case 2: 
                mirrorPoint(x1, y1, 0, 1, &newX1, &newY1);
                mirrorPoint(x2, y2, 0, 1, &newX2, &newY2);
                mirrorPoint(x3, y3, 0, 1, &newX3, &newY3);
                break;
            case 3: 
                mirrorPoint(x1, y1, 1, 1, &newX1, &newY1);
                mirrorPoint(x2, y2, 1, 1, &newX2, &newY2);
                mirrorPoint(x3, y3, 1, 1, &newX3, &newY3);
                break;
            case 4: 
                printf("Enter scaling factor for X-axis: ");
                scanf("%f", &scaleX);
                printf("Enter scaling factor for Y-axis: ");
                scanf("%f", &scaleY);
                scalePoint(x1, y1, scaleX, scaleY, &newX1, &newY1);
                scalePoint(x2, y2, scaleX, scaleY, &newX2, &newY2);
                scalePoint(x3, y3, scaleX, scaleY, &newX3, &newY3);
                break;
            case 5: 
                printf("Enter shearing factor for X-axis: ");
                scanf("%f", &shearX);
                printf("Enter shearing factor for Y-axis: ");
                scanf("%f", &shearY);
                shearPoint(x1, y1, shearX, shearY, &newX1, &newY1);
                shearPoint(x2, y2, shearX, shearY, &newX2, &newY2);
                shearPoint(x3, y3, shearX, shearY, &newX3, &newY3);
                break;
            case 6: 
                printf("Enter rotation angle (in degrees): ");
                scanf("%f", &angle);
                rotatePoint(x1, y1, angle, &newX1, &newY1);
                rotatePoint(x2, y2, angle, &newX2, &newY2);
                rotatePoint(x3, y3, angle, &newX3, &newY3);
                break;
            case 7: 
                newX1 = originalX1; newY1 = originalY1;
                newX2 = originalX2; newY2 = originalY2;
                newX3 = originalX3; newY3 = originalY3;
                break;
            default:
                printf("Invalid choice! Try again.\n");
                continue;
        }

        
        x1 = newX1; y1 = newY1;
        x2 = newX2; y2 = newY2;
        x3 = newX3; y3 = newY3;
    }

    closegraph(); 
    return 0;
}
